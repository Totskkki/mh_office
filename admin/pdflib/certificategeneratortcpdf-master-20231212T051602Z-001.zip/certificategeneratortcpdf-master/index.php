<!DOCTYPE html>
<html>
  <head>
    <title>Certificate Generator</title>
  </head>
  <body>
    <form method="post" action="generate_certificate.php">
      Name:
      <input type="text" name="name">
      <br>
      Course:
      <input type="text" name="course">
      <br>
      Date:
      <input type="date" name="date">
      <br>
      <button type="submit">Generate</button>
    </form>
  </body>
</html>
